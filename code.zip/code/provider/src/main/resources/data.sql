insert into user(id,username,name,age,balance) values(1,'user1','sdfa',20,100.00);
insert into user(id,username,name,age,balance) values(2,'user2','sdfga',26,200.00);
insert into user(id,username,name,age,balance) values(3,'user3','sdafa',23,400.00);
insert into user(id,username,name,age,balance) values(4,'user4','asdfa',30,100.05);