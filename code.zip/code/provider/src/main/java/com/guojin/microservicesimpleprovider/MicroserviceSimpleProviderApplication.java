//user microservice 
//get info by user id
package com.guojin.microservicesimpleprovider;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class MicroserviceSimpleProviderApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceSimpleProviderApplication.class, args);
	}
}
