package com.guojin.microservicecusomer.feign;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.guojin.microservicecusomer.entity.User;

@FeignClient("microservice-provider-user")
public interface UserFeignClient {
	
    @RequestMapping(method = RequestMethod.GET, value = "/user/{id}", consumes = "application/json")
    public User findById(@PathVariable("id") Long id);
    
    @RequestMapping(value="/user", method=RequestMethod.POST,consumes = "application/json")
    public User postUser(@RequestBody User user);
}
